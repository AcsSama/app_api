<?php
// config.php
$DB_HOST = "sql105.iceiy.com";
$DB_PORT = 3306;
$DB_NAME = "icei_40860776_game_market";
$DB_USER = "icei_40860776";
$DB_PASS = "r4cgzrcRlWV7X";
